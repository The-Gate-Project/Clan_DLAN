BEGIN ~Taim~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN 1
   SAY @0
       IF ~~ THEN REPLY @1 GOTO 2
       IF ~~ THEN REPLY @2 GOTO 3
END

IF ~~ THEN BEGIN 2
   SAY @3
       IF ~~ THEN REPLY @4 DO ~JoinParty()~ EXIT
END

IF ~~ THEN BEGIN 3
   SAY @5
       IF ~~ THEN REPLY @6 EXIT
END

IF ~NumTimesTalkedToGT(0)~ THEN BEGIN 4
   SAY @7
       IF ~~ THEN REPLY @8 DO ~JoinParty()~ EXIT
       IF ~~ THEN REPLY @9 EXIT
END