JUEGO:      Baldur's Gate II
MOD: 	    ULDAR, Semiorco Barbaro,
VERSI�N:    0.77
CREADOR:    Sergiond

Por favor contacta con Sergiond ( sergiond77@hotmail.com ) si encuentras en el mod alg�n error u otro imprevisto.


�NDICE:
  	 I. Instalaci�n y desinstalaci�n
        II. Compatibilidades
       III. Acerca del mod
        IV. Cr�ditos
         V. Agradecimientos
        VI. Qu� le falta
       VII. Versiones

I. INSTALACI�N:

- Asegurate previamente de que has instalado correctamente BG2: SoA y su expansi�n ToB. 

- Ejecuta el archivo comprimido UldarNPC.rar y selecciona el directorio principal de BG2.
- Ejecuta Setup-Uldar.exe
- Este mod puede ser instalado/desinstalado sin causar ning�n problema a la instalaci�n de BG2.
- Para DESINSTALAR:  Ejecuta de nuevo Setup-Uldar.exe y te dar� las opciones de reinstalar o desinstalar.

II. COMPATIBILIDADES:

- Este mod es compatible con SoA y con ToB. Por otro lado es obligatorio tener ambas instaladas.
- Es compatible tambi�n con cualquier otro mod ya que est� compilado con Weidu.

III. ACERCA DEL MOD:

  En el mod Uldar NPC podr�s encontrar lo siguiente:

- Uldar, un b�rbaro semiorco que podr� unirse a tu grupo. Inicialmente se encuentra en la Corona de Cobre. Si juegas a ToB, 
  podr�s invocarlo en la Bolsa Planar.
- El mod NO tiene romance pero aporta gran cantidad de di�logos e interacciones, casi siempre con varias opciones de respuesta.

IV. CR�DITOS:

-   Idea y dise�o:                             Sergiond 
-   Programaci�n y desarrollo:                 Sergiond


V. AGRADECIMIENTOS:

- Gracias a DLAN, por toda la informaci�n y recursos que tienen a disposici�n de los modders en castellano. Es obligatorio 
  visitar DLAN en http://www.clandlan.net/
- Special thanks to the "machines" Jason Compton, Simding0 and Camdawg from PocketPlanet. They were very tolerant with my 
  questions and with my poor english. You can meet them and their mods in http://www.pocketplane.net/
- Hay otra p�gina de la que, personalmente, creo que tienen uno de los mejores tutoriales en castellano para di�logos que 
  existen, �buen trabajo Riojano2002!. La direcci�n es http://www.laforjacelestial.tk/
- Westley Weimer for WeiDU. His page is http://www.weidu.org
- Bioware for having such a great game that I want to expand on it.

- Gracias, muy especialmente, a Immortality de DLAN.   :D



VI. QU� LE FALTA

- M�s interacciones con NPCs.
- 2 subquests.
- Varios objetos para b�rbaro.
- Depurar la forma de expresarse de Uldar para que suene m�s a "b�rbaro".


VII. VERSIONES

  0.77  - Lollorian's !Dead(Myself) correction to baf/Uldarx.baf (http://www.shsforums.net/topic/42220-fixes-for-the-big-fixpack/page__view__findpost__p__483485),
          added README command and updated to WeiDU v215.
  0.76  - Zeroed effects and items offsets in CRE-files, added VERSION-flag and updated to WeiDU v210.
  0.75  - Todav�a est� en BETA pero ya aporta un gran n�mero de di�logos. Incluye tambi�n sus voces y su ep�logo para el TOB.

