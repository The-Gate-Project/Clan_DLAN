BEGIN ~Uldarsc1~

//IF ~NumTimesTalkedTo(0) !Dead("announcer") !StateCheck("announcer",STATE_SLEEPING)~ THEN BEGIN Gladiador 
//  SAY ~�No luchar�! �Esto es algo inhumano! ��C�mo puedes soportar que esto siga?! ��C�mo puedes...?!~ [GLAD101]
//  IF ~~ THEN EXTERN ~ANNO1~ 2
//END



IF ~NumTimesTalkedTo(0) !Dead("announcer") !StateCheck("announcer",STATE_SLEEPING)~ THEN BEGIN Gladiador 
  SAY ~��No luchar�!! �No os dar� el placer de ver m�s sangre vertida por mi causa!~
  IF ~~ THEN EXTERN ~ANNO1~ 2
END

 
IF ~~ THEN BEGIN 1
  SAY ~�Malditos! �Me hab�is obligado a matar a esta pobre bestia solo para saciar vuestra sed de sangre!  (el gladiador levanta su hacha amenazadoramente hacia los guardias)~
  IF ~~ THEN EXTERN ~ULDGUA1~ 1
END


