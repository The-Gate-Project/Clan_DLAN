BEGIN ~GIRL2~

IF ~NumTimesTalkedTo(0)
~ THEN BEGIN 0 
  SAY ~(jadeo) Muchas... muchas gracias, por salvar mi vida. Intent� escapar pero me pillaron y ahora quer�an darme un castigo ejemplar para el resto de ni�os. �Seguro que ese monstruo me habr�a matado!~
  IF ~~ THEN REPLY ~Es verdad. Ahora est�is libres, as� que os sugiero que huy�is mientras pod�is.~ GOTO 1
END

IF ~~ THEN BEGIN 1 
  SAY ~S�, s�, se�or. No s� d�nde iremos. Scornubel est� tan lejos... �Pero cualquier cosa es mejor que luchar para que esos malvados se r�an de nosotros!~ ~S�, s�, se�ora. No s� d�nde iremos. Scornubel est� tan lejos... �Pero cualquier cosa es mejor que luchar para que esos malvados se r�an de nosotros!~
  IF ~~ THEN REPLY ~�Por qu� los esclavistas tienen tantos ni�os aqu�?~ GOTO 2
  IF ~PartyGoldGT(99)~ THEN REPLY ~Aqu� hija. Aqu� hay 100 piezas de oro... mira a ver si con esto t� y estos otros ni�os pod�is volver al lugar del que ven�s.~ DO ~TakePartyGold(100)~ GOTO 3
  IF ~~ THEN REPLY ~�No importa, chica, t� corre!~ GOTO 4
END

IF ~~ THEN BEGIN 2 
  SAY ~Yo, no estoy segura. Creo que uno de ellos dijo que formabamos parte del siguiente pedido para un nuevo cliente muy poderoso. Dijo que necesitaba reunir a diez ni�os m�s antes de que acabara la semana. �No s� que habr�a pasado si no nos hubieras salvado!~
  IF ~PartyGoldGT(99)~ THEN REPLY ~Bueno, aqu� hay 100 piezas de oro, hija. Quiz� esto os ayude a algunos de vosotros a volver a vuestras casas.~ DO ~TakePartyGold(100)~ GOTO 3
  IF ~~ THEN REPLY ~Ya. Bueno, ya sois libres, �as� que ahora corred mientras pod�is!~ GOTO 4
END

IF ~~ THEN BEGIN 3
  SAY ~�Oh! Eres demasiado amable, se�or. Esto, esto puede que pueda llevar a algunos de los nuestros a casa. Gracias, de verdad.~ ~�Oh! Eres demasiado amable, se�ora. Esto, esto puede que pueda llevar a algunos de los nuestros a casa. Gracias, de verdad.~
  IF ~~ THEN REPLY ~En serio. Sois libres, ahora... �marchaos, mientras pod�is!~ GOTO 5
END

IF ~~ THEN BEGIN 4
  SAY ~�Vale! �Gracias otra vez, se�or! �Estoy seguro de que la Dama de la Alegr�a os sonreir�!~ ~�Vale! �Gracias otra vez, se�ora! �Estoy seguro de que la Dama de la Alegr�a os sonreir�!~
  IF ~!IsValidForPartyDialog("Aerie")
!IsValidForPartyDialog("Anomen")
!IsValidForPartyDialog("Jaheira")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()
~ EXIT
  IF ~IsValidForPartyDialog("Aerie")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()
~ EXTERN ~AERIEJ~ 53
  IF ~!IsValidForPartyDialog("Aerie")
IsValidForPartyDialog("Anomen")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()
~ EXTERN ~ANOMENJ~ 179
  IF ~!IsValidForPartyDialog("Aerie")
!IsValidForPartyDialog("Anomen")
IsValidForPartyDialog("Jaheira")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()~ EXTERN ~JAHEIRAJ~ 349
END

IF ~~ THEN BEGIN 5 // from: 3.0
  SAY #48460 /* ~�Vale! �Gracias otra vez, se�or! �Estoy seguro de que la Dama de la Alegr�a os sonreir�!~ ~�Vale! �Gracias otra vez, se�ora! �Estoy seguro de que la Dama de la Alegr�a os sonreir�!~ */
  IF ~!IsValidForPartyDialog("Nalia")
!IsValidForPartyDialog("Yoshimo")
!IsValidForPartyDialog("Korgan")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()~ EXIT
  IF ~IsValidForPartyDialog("Nalia")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()~ EXTERN ~NALIAJ~ 226
  IF ~!IsValidForPartyDialog("Nalia")
IsValidForPartyDialog("Yoshimo")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()~ EXTERN ~YOSHJ~ 38
  IF ~!IsValidForPartyDialog("Nalia")
!IsValidForPartyDialog("Yoshimo")
IsValidForPartyDialog("Korgan")~ THEN DO ~SetGlobal("FreeSlaves","GLOBAL",1)
AddexperienceParty(3500)
ReputationInc(1)
EscapeArea()~ EXTERN ~KORGANJ~ 57
END
