

BEGIN ~BOY3~

IF ~NumTimesTalkedTo(0)
~ THEN BEGIN 0 
  SAY ~�Oh, gracias, se�or! �Muchas gracias por dejarme salir de aqu�! �Ten�a tanto miedo!~ ~�Oh, gracias, se�ora! �Muchas gracias por dejarme salir de aqu�! �Ten�a tanto miedo!~ 
  IF ~~ THEN GOTO 1
END

IF ~~ THEN BEGIN 1 
  SAY ~�Me voy de aqu�!~ 
  IF ~~ THEN DO ~AddexperienceParty(2500) SetGlobal("Celdani�oUldar","GLOBAL",1) EscapeArea()~ EXIT
END
