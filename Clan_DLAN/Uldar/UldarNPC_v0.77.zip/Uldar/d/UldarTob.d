EXTEND_TOP FATESP 6

   IF ~!Dead("Uldar")
       !InMyArea("Uldar")
       Global("UldarSummoned","GLOBAL",0)~ THEN

      REPLY ~Tr�eme a Uldar, al b�rbaro semiorco de la orgullosa tribu de los Hatuk.~ DO ~SetGlobal("UldarSummoned","GLOBAL",1)~ GOTO 8
END


