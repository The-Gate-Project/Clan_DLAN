BEGIN ~Uldar~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN PrimerContacto
  SAY ~�Eh, vosotros! �AQU�!~
      =
      ~�Ten�is que liberadnos! �No permit�is que hagan da�o a los ni�os que tienen encarcelados en una de estas celdas! �Salvad a los peque�os y os estar� eternamente agradecido!~
  IF ~~ THEN REPLY ~No te preocupes, la esclavitud tiene aqu� sus d�as contados. �Pronto ser�is todos libres!~ DO ~SetGlobal("Uldaragradecido","GLOBAL",1)~ EXIT
  IF ~~ THEN REPLY ~Tranquilo gladiador pronto....euhh...esto... (detr�s de los barrotes distingues una corpulenta figura humanoide de portentosos m�sculos y piel verdosa; sus rasgos faciales se te antojan deformes pues su gran boca esconde una prominente dentadura de grandes colmillos y su nariz chata recuerda a la de los puercos)~ DO ~SetGlobal("Uldaragradecido","GLOBAL",1)~ GOTO Semiorco
  IF ~~ THEN REPLY ~Te equivocas, no estoy en contra de lo que aqu� hay montado; de hecho, me encanta veros encerrados ah� dentro �jajajaja!~ DO ~SetGlobal("Uldaragradecido","GLOBAL",1)~ GOTO Decepcion
END

IF ~~ THEN BEGIN Semiorco
  SAY ~No...no os asust�is. Me llamo Uldar, anta�o orgulloso guerrero y cazador...ahora esclavo y gladiador...Y s�, por mis venas corre sangre orca...soy un semiorco...~
IF ~!Race(Player1,HALFORC)~ THEN REPLY ~Tranquilo... No puedo negar que al verte me he sorprendido, pero no soy de los que juzgan por las apariencias Uldar. �Pronto os liberar�!~ ~Tranquilo...No puedo negar que al verte me he sorprendido, pero no soy de las que juzgan por las apariencias Uldar. �Pronto volver� para liberaros!~ EXIT
IF ~!Race(Player1,HALFORC)~ THEN REPLY ~�Eres el v�stago de un sucio orco? �Todo orco es escoria a la que se le ha de dar muerte! Lo se bien puesto que en el pasado tuve que dar cuenta de muchos de ellos. Lo siento semiorco pero no me fio. No ser� yo quien deje libre en las calles de Athkatla a alguien de tu especie. Adios. ~ GOTO Decepcion
IF ~Race(Player1,HALFORC)~ THEN REPLY ~No has de avergonzarte de nada Uldar...Fijate bien, yo tambi�n soy como tu, me llamo <CHARNAME> y soy un semiorco. Aguanta un poco m�s, pronto quedar�s libre.~ ~No has de avergonzarte de nada Uldar...Fijate bien, yo tambi�n soy como tu, me llamo <CHARNAME> y soy una semiorca. Aguanta un poco m�s, pronto quedar�s libre.~EXIT
END

IF ~~ THEN BEGIN Decepcion
  SAY ~�Grrr...<RACE>, da gracias a que estos gruesos barrotes te protegen de mi furia! ��QUE ALGUIEN ME SAQUE DE AQUIIII!!~
  IF ~~ THEN DO ~SetGlobal("Uldardecepcionado","GLOBAL",1)~ EXIT
END


IF ~NumTimesTalkedToGT(0) Global("Uldardecepcionado","GLOBAL",1) Global("Celdani�oUldar","GLOBAL",0) !PartyHasItem("MISC4Z")~ THEN BEGIN FuerademiVista     
  SAY ~�Fuera de mi vista! �Odio a los esclavistas!.~
  IF ~~ THEN EXIT 
END

IF ~NumTimesTalkedToGT(0) Global("Uldardecepcionado","GLOBAL",1) Global("Celdani�oUldar","GLOBAL",0) PartyHasItem("MISC4Z")~ THEN BEGIN Sorpresa 
  SAY ~��Has conseguido la llave?!. Puede que me equivocara al juzgarte... �R�pido, libera primero a los ni�os y a lo dem�s gladiadores!~
  IF ~~ THEN EXIT 
END

IF ~NumTimesTalkedToGT(0) !Global("Uldardecepcionado","GLOBAL",1) Global("Celdani�oUldar","GLOBAL",0) PartyHasItem("MISC4Z")~ THEN BEGIN Liberado                
  SAY ~��Tienes la llave?! �R�pido, libera primero a los ni�os y a lo dem�s gladiadores!~
  IF ~~ THEN REPLY ~Est� bien, as� lo haremos~  EXIT 
END


//IF ~NumTimesTalkedToGT(0) Global("Celdani�oUldar","GLOBAL",1) Global("HendakReleased","AR0406",2) 

IF ~NumTimesTalkedToGT(0) Global("HendakReleased","AR0406",2) Global("PuertaAbiertaUldar","GLOBAL",1) Global("UldarLibre","GLOBAL",0)~ THEN BEGIN Liberado    
  SAY ~�Gracias, has liberado a los peque�os y a mis camaradas tal y como te ped�! ��BIEN!! �Primero machaquemos las cabezas de algunos esclavistas! �Ya hablaremos luego acompa�ados por una buena jarra de cerveza!~ 
      =
      ~�VENID AQU� SUCIOS PEDAZOS DE CARNE ESCLAVISTA, OS VOY A ARRANCAR EL CORAZ�N! ��UUUAAARRRRGGGGG!!~  
  IF ~~ THEN REPLY ~(La mirada asesina del semiorco anima a apartarse de su camino mientras este se abre paso por los pasillos dando grandes zancadas y echando espumarajos por la boca...en cierto sentido, sientes l�stima por aquellos pobres esclavistas que se crucen con �l).~ DO ~SetGlobal("TomandoCerveza","GLOBAL",1) SetGlobal("UldarLibre","GLOBAL",1) EscapeAreaMove("AR0406",1373,1760,3)~ EXIT
END


//51*********************************************************************************************************


IF ~NumTimesTalkedToGT(0) Global("HendakReleased","AR0406",3) Global("TomandoCerveza","GLOBAL",1) Global("UldarAgradece","GLOBAL",0)~ THEN BEGIN Descansando    
  SAY ~�Uldar te saluda <CHARNAME>! �Todos hablan ti y de como has expulsado a los esclavistas de la Corona de Cobre!~
      =   
      ~�Al final conseguiste liberarnos a todos!~
  IF ~~ THEN REPLY ~Esa escoria tuvo lo que se merec�a.~ GOTO Agradecido
  IF ~~ THEN REPLY ~S�, lo cierto es que no pod�a permanecer impasible ante lo que aqu� estaba sucediendo.~ GOTO Agradecido
  IF ~~ THEN REPLY ~Lehtinan no fue nada razonable, el se lo busc�.~ GOTO Agradecido
END


IF ~~ THEN BEGIN Agradecido
  SAY ~S�, tus actos han salvado muchas vidas, sobre todo la de los ni�os que ten�an secuestrados. Si les hubiera pasado algo nunca me lo hubiera perdonado.~
      =
      ~Afortunadamente todo ha salido bien. Adem�s, ya me he ocupado de los peque�os, me he asegurado de que puedan volver a su casa con su madre.~
  IF ~~ THEN REPLY ~Veo que te has tomado muy en serio la protecci�n de esos chavales...~ GOTO Chavales
  IF ~~ THEN REPLY ~Todo un detalle por tu parte Uldar. Por cierto, �qu� piensas hacer ahora que ya no tienes que ser m�s un gladiador para los esclavistas?...Te propongo unirte a mi grupo. Nos vendr�a bien un guerrero como tu.~ GOTO Propuesta2
  IF ~Global("Uldaragradecido","GLOBAL",1)~ THEN REPLY ~Por cierto, recuerdo que antes, en las celdas, me digiste que me lo agradecer�as "eternamente" si liberaba a los chavales...~ GOTO Propuesta1 
END

IF ~~ THEN BEGIN Chavales
  SAY ~As� es... as� se lo promet� a su padre en la arena...(Tras suspirar, el pensativo semiorco empina con impetu su gran jarra y de un solo trago se bebe toda la cerveza que conten�a, como si con ello intentase espantar fantasmas del pasado).~
      =
      ~�Uuaah, se acabo la cerveza! (El semiorco deja con fuerza la jarra vac�a sobre la mesa mientra suelta un estruendoso erupto) �Bien, creo entonces que ha llegado el momento de salir de esta ciudad infecta y regresar a mis monta�as!~
  IF ~~ THEN REPLY ~Espera Uldar, �y si te unieras al grupo?. Nos vendr�a bien un guerrero como tu.~ GOTO Propuesta2
  IF ~~ THEN REPLY ~Haces bien en salir de aqu�. Yo mismo lo har�a de no ser por unos asuntos de gran importancia que me retienen. �Buen viaje Uldar!~ ~Haces bien en salir de aqu�. Yo misma lo har�a de no ser por unos asuntos de gran importancia que me retienen. �Buen viaje Uldar!~DO ~EscapeArea()~ EXIT
END


IF ~~ THEN BEGIN Propuesta1
  SAY ~S�...as� fue. Y Uldar siempre cumple su palabra.~
      =
      ~Pero en poco puede recompensarte este b�rbaro del norte por tu haza�a, salvo poniendo su fuerte brazo a tu servicio...si es eso lo que deseas.~ 
  IF ~~ THEN REPLY ~Bueno, supongo que ha de valer, me consta de que tu habilidad en el combate podr� serme muy �til.~ DO ~SetGlobal("UldarAgradece","GLOBAL",1) SetGlobal("UldarAdmitido","GLOBAL",1) SetGlobal("DialogosconUldar","LOCALS",1) SetGlobalTimer("UldarDialogo","GLOBAL",FOUR_DAYS) JoinParty()~ EXIT 
  IF ~~ THEN REPLY ~�Viajar con un semiorco? �Y que hay de mi reputaci�n? �Eso no me sirve para nada! En fin, ya que no puedo sacar nada de valor, agradecemelo desapareciendo de mi vista, ese es mi deseo b�rbaro.~ DO ~EscapeArea()~ EXIT
  IF ~~ THEN REPLY ~Lo tendr� en cuenta Uldar, pero ahora no puede ser. Permanece aqu�, si te necesito volver� a por ti.~ DO ~SetGlobal("UldarAgradece","GLOBAL",1) SetGlobal("UldarEsperando","GLOBAL",1)~ EXIT
  IF ~~ THEN REPLY ~No esperaba un mejor agradecimiento. Sin duda nos vendr� muy bien contar contigo Uldar.~ DO ~SetGlobal("UldarAgradece","GLOBAL",1) SetGlobal("UldarAdmitido","GLOBAL",1) SetGlobal("DialogosconUldar","LOCALS",1) SetGlobalTimer("UldarDialogo","GLOBAL",FIVE_DAYS) JoinParty()~ EXIT 
END

IF ~~ THEN BEGIN Propuesta2
  SAY ~�Unirme a ti? �Lo dices en serio?~
      =
      ~�Uldar se sentir�a muy orgulloso de compartir camino junto a <CHARNAME>!~ 
  IF ~~ THEN REPLY ~�Estupendo! �Ven entonces! �Pongamonos en marcha!~ DO ~SetGlobal("UldarAgradece","GLOBAL",1) SetGlobal("UldarAdmitido","GLOBAL",1) SetGlobal("DialogosconUldar","LOCALS",1) SetGlobalTimer("UldarDialogo","GLOBAL",FIVE_DAYS) JoinParty()~ EXIT 
  IF ~~ THEN REPLY ~�Excelente Uldar! Espera entonces aqu�. Pronto vendr� a pedirte ayuda.~ DO ~SetGlobal("UldarAgradece","GLOBAL",1) SetGlobal("UldarEsperando","GLOBAL",1)~ EXIT
END


IF ~NumTimesTalkedToGT(0) Global("TomandoCerveza","GLOBAL",1) Global("UldarEsperando","GLOBAL",1) Global("UldarAdmitido","GLOBAL",0)~ THEN BEGIN BebiendoCerveza
  SAY ~�Es bueno verte <CHARNAME>!. �Necesitas de la fuerza de Uldar?~
  IF ~~ THEN REPLY ~As� es, orgulloso guerrero. Requerimos de tus habilidades. �Bienvenido!~ DO ~SetGlobal("UldarAdmitido","GLOBAL",1) SetGlobal("DialogosconUldar","LOCALS",1) SetGlobalTimer("UldarDialogo","GLOBAL",FOUR_DAYS) JoinParty()~ EXIT
  IF ~~ THEN REPLY ~Ahora no, quiz�s m�s tarde.~ EXIT
  IF ~~ THEN REPLY ~No por ahora, solo pasaba para saludar.~ EXIT
END



//110*********************************************************
//************************************************************

BEGIN ~UldarP~   


IF ~Global("UldarAdmitido","GLOBAL",1)~ THEN BEGIN DejarGrupo
  SAY ~�Es hora de que Uldar y <CHARNAME> recorran senderos distintos?~
    IF ~~ THEN REPLY ~Nada de eso, �siguamos adelante compa�ero!~ DO ~JoinParty()~ EXIT
    IF ~Global("UldarLealtad","GLOBAL",0)~ THEN REPLY ~As� es, creo que deber�as marcharte.~ GOTO CoroCobre
    IF ~Global("UldarLealtad","GLOBAL",1)~ THEN REPLY ~As� es, creo que deber�as marcharte.~ GOTO Infierno
END

IF ~~ THEN BEGIN CoroCobre
  SAY ~Como quieras <CHARNAME>.~
      =
      ~Si me necesitas estar� en la Corona de Cobre. Estar� bien beber cerveza con Hendak y con el resto de mis viejos camaradas gladiadores.~
  IF ~~ THEN REPLY ~Muy bien Uldar, all� nos veremos.~ DO ~SetGlobal("UldarAdmitido","GLOBAL",0) EscapeAreaMove("AR0406",1373,1760,3)~ EXIT
END  

IF ~~ THEN BEGIN Infierno
  SAY ~Muy bien, te esperar� aqu� mismo por si me necesitas.~
  IF ~~ THEN DO ~SetGlobal("UldarAdmitido","GLOBAL",0)~ EXIT
END  

 
IF ~Global("UldarAdmitido","GLOBAL",0)~ THEN BEGIN Reencuentro
  SAY ~�Es bueno verte <CHARNAME>!. �Necesitas de la fuerza de Uldar?~
  IF ~~ THEN REPLY ~As� es, orgulloso guerrero. Requerimos de tus habilidades.�Bienvenido!~ DO ~SetGlobal("UldarAdmitido","GLOBAL",1) JoinParty()~ EXIT
  IF ~~ THEN REPLY ~No, s�lo pasaba para saludarte.~ EXIT
END


//*********************************************************
//144******************************************************


BEGIN ~Uldarj~


IF ~AreaCheck("AR0400") Global("UldarBarco1","GLOBAL",0)~ THEN BEGIN MisionCHARNAME
  SAY ~�Por fin, el cielo abierto!...No es que se pueda comparar al de las altas monta�as, pero sin duda el cielo en la ciudad adquiere una gran belleza cuando se ve con ojos libres...~ 
  IF ~~ THEN REPLY ~A mi y a unos amigos tambi�n nos tuvieron hasta hace poco encarcelados en esta misma ciudad, incluso nos torturaron, as� que puedo entender la dicha que sientes. Me alegra haber ayudado.~ GOTO UldarsabedeIrenicus
  IF ~~ THEN REPLY ~Me agrada haberte sido de ayuda pero ahora puedes cumplir la promesa que me hiciste, me vendr�a muy bien tu ayuda en la caza de un mago llamado Irenicus y en el rescate de Imoen, ambos retenidos por los Magos Encapuchados de Athkatla.~ GOTO Uldarseapunta
END


IF ~~ THEN BEGIN UldarsabedeIrenicus
  SAY ~�Ummff! ��Qu� le pasa a esta ciudad?! ���Es qu� no conocen otra forma de vivir que no sea a costa de negar la libertad y hacer sufrir a los dem�s?!!~
      =
      ~...Pero ahora eres libre... �Ya te habr�s vengado de tu carcelero, verdad?~
  IF ~~ THEN REPLY ~No. Lo cierto es que el culpable, un mago llamado Irenicus, consigui� escapar gracias a que los Magos Encapuchados se lo llevaron detenido. Pero no estoy dispuesto que esto quede as�, lo encontrar� y se lo har� pagar.~ ~No. Lo cierto es que el culpable, un mago llamado Irenicus, consigui� escapar gracias a que los Magos Encapuchados se lo llevaron detenido. Pero no estoy dispuesta que esto quede as�, lo encontrar� y se lo har� pagar.~GOTO Uldarseapunta 
  IF ~~ THEN REPLY ~No. Lo cierto es que el culpable, un mago llamado Irenicus, consigui� escapar gracias a que los Magos Encapuchados se lo llevaron detenido. Y no solo eso, debido a la intervenci�n de estos, una amiga m�a llamada Imoen tambi�n fue arrestada por esta poderosa organizaci�n. Como ves, estoy de lleno en una misi�n para rescatar a Imoen y darle su merecido a ese tal Irenicus.~ GOTO Uldarseapunta
END


IF ~~ THEN BEGIN Uldarseapunta
  SAY ~�Pues escucha entonces el juramento de un guerrero Hatuk amigo mio: Tu me has devuelto la libertad y yo, mientras me necesites, estar� a tu lado! �Juntos rescataremos a Imoen y juntos daremos caza a ese villano llamado Irenicus! Es lo m�nimo que puedo hacer por ti. A parte de eso, poco m�s puedo ofrecerte ya que conozco bien poco a esos Magos Encapuchados. Lo cierto es que soy todo un extra�o en esta ciudad. Siento no serte de m�s ayuda.~  
      ~�Pues escucha entonces el juramento de un guerrero Hatuk amiga mia: Tu me has devuelto la libertad y yo, mientras me necesites, estar� a tu lado! �Juntos rescataremos a Imoen y juntos daremos caza a ese villano llamado Irenicus! Es lo m�nimo que puedo hacer por ti. A parte de eso, poco m�s puedo ofrecerte ya que conozco bien poco a esos Magos Encapuchados. Lo cierto es que soy todo un extra�o en esta ciudad. Siento no serte de m�s ayuda.~

  IF ~~ THEN REPLY ~No te preocupes por eso Uldar. Lo que importa es saber que podr� contar contigo.~ EXIT
  IF ~~ THEN REPLY ~�Excelente! Tu palabra te obliga gran guerrero y me consta que ser� fiel a ella hasta las �ltimas consecuencias.~ EXIT
  IF ~~ THEN REPLY ~�Bien! �Pongamonos entonces en marcha! �No hay tiempo que perder!~ EXIT
END


IF ~AreaCheck("AR0405") See([ENEMY]) Global("UldarBarco1","GLOBAL",0)~ THEN BEGIN EntradaBarco1 
  SAY ~Grrrr... �M�s esclavistas! ��LOS VOY A MATAR A TODOS!!~ 
  IF ~~ THEN DO ~SetGlobal("UldarBarco1","GLOBAL",1)~ EXIT
END


IF ~AreaCheck("AR0405") !See([ENEMY]) Global("UldarBarco2","GLOBAL",0)~ THEN BEGIN EntradaBarco2 
  SAY ~S�, conozco bien este barco (mientras habla, el b�rbaro recorre cada rinc�n del lugar con una mirada de aut�ntico odio)... Aqu� es donde esconden a los esclavos hasta que son vendidos en subasta.~ 
  IF ~~ THEN REPLY ~�As� que te tuvieron encerrado aqu�?~ DO ~SetGlobal("UldarBarco2","GLOBAL",1)~ GOTO EntradaBarco3
END

IF ~~ THEN BEGIN EntradaBarco3
  SAY ~S�... (te quedas mirando a Uldar e intuyes que habr�a querido a�adir algo m�s, pero notas como si la mente del semiorco viajara en el tiempo. Probablemente est� recordando los malos momentos que tuvo que pasar dentro de esta embarcaci�n)~
      = 
      ~�<CHARNAME>, seguro que tendr�n a gente encerrada aqu�! �Debemos rescatarlos a todos!~
  IF ~~ THEN REPLY ~Eso est� hecho Uldar. No dejaremos un rinc�n sin mirar.~ EXIT
  IF ~~ THEN REPLY ~�Claro! Adem�s, seguro que Hendak nos tiene preparada otra recompensa si conseguimos echar a bajo este negocio.~ EXIT
END

IF ~AreaCheck("AR0405")  Global("QueesJarall","GLOBAL",1)~ THEN BEGIN QueesJarall 
  SAY ~�Te has fijado en este hombre que acompa�aba a los yuantis? Nunca antes hab�a visto algo igual...~
  IF ~~ THEN REPLY ~S�, aunque parece humano, esos ojos de reptil y esa piel escamosa reflejan claramente su parentesco con los yuantis... �qu� estar�an estos haciendo aqu�?~ GOTO QuedeciaJarall
  IF ~~ THEN REPLY ~Creo recordar haber leido algo sobre este tipo de hombres serpiente en Candelero. Se denominan Puracasta y es muy mal asunto verlos aqu�. Los yuantis suelen usarlos para infiltrarse entre comunidades humanas y llevar a cabo alg�n oscuro plan.~ GOTO QuedeciaJarall
  IF ~~ THEN REPLY ~Parece que se trata de alg�n tipo de hombre serpiente, con m�s apariencia humana de la que he visto en otras ocasiones...~ GOTO QuedeciaJarall
END

IF ~~ THEN BEGIN QuedeciaJarall
  SAY ~Todo esto es muy extra�o...�Oiste lo que dijo sobre un Profeta?. ~
  IF ~~ THEN REPLY ~S�, tambi�n lo escuch�, pero no se a que se refer�a. Quiz�s encontremos algo entre sus pertenecias que de un poco m�s de luz sobre este misterio.~ DO ~SetGlobal("QueesJarall","GLOBAL",2)~ EXIT
  IF ~~ THEN REPLY ~Ni idea a que podr�a referirse con eso, pero bastante turbio parece el asunto como para adem�s mezclarlo con videntes parlanchines y conspiradores . Miremos entre sus cosas a ver si encontramos algo que aclare un poco m�s todo esto.~ DO ~SetGlobal("QueesJarall","GLOBAL",2)~ EXIT
END


//***********************************************************
//211***********************************************************

I_C_T HAEGAN 1 UldarHaegan
== ULDARJ IF ~InParty("Uldar")~ THEN ~�Pronto acabar� todo pedazo de carne! ��Voy a matarte!! ��UUARRGGGG!!~
== HAEGAN IF ~InParty("Uldar")~ THEN ~�Te recuerdo! �Yo te vend� a Lehtinan para que hiciera de ti un gladiador! �No me das miedo esclavo! ��VAMOS!! ��Te ense�ar� cual es tu lugar escoria semiorca!!~
END

I_C_T HAEGAN 2 UldarHaegan
== ULDARJ IF ~InParty("Uldar")~ THEN ~�Pronto acabar� todo pedazo de carne! ��Voy a matarte!! ��UUARRGGGG!!~
== HAEGAN IF ~InParty("Uldar")~ THEN ~�Te recuerdo! �Yo te vend� a Lehtinan para que hiciera de ti un gladiador! �No me das miedo esclavo! ��VAMOS!! ��Te ense�ar� cual es tu sitio escoria semiorca!!~
END

I_C_T HAEGAN 3 UldarHaegan
== ULDARJ IF ~InParty("Uldar")~ THEN ~�Pronto acabar� todo pedazo de carne! ��Voy a matarte!! ��UUARRGGGG!!~
== HAEGAN IF ~InParty("Uldar")~ THEN ~�Te recuerdo! �Yo te vend� a Lehtinan para que hiciera de ti un gladiador! �No me das miedo esclavo! ��VAMOS!! ��Te ense�ar� cual es tu sitio escoria semiorca!!~
END


I_C_T VICG1 3 UldarArdeVico
== ULDARJ IF ~InParty("Uldar")~ THEN ~�Una drow?...Los ancianos de mi tribu podr�an contarnos dos o tres buenas historias sobre ellos. Yo es la primera vez que veo una de su especie, pero si es cierto lo que se cuenta de ellos, no es de extra�ar que estas gentes la quieran quemar viva.~
END


I_C_T HENDAK 31 FinEsclavistas
== ULDARJ IF ~InParty("Uldar")~ THEN ~No estar�s solo en ello Hendak, yo tambi�n estar� alerta. Se lo debemos a todos los que fueron esclavos; sobre todo a todos nuestros camaradas gladiadores que perdieron la vida en el foso.~
== HENDAK IF ~InParty("Uldar")~ THEN ~S�, son muchas las vidas que se ha llevado el infame negocio que aqu� ten�an montado Lehtinan y Haegan aunque ya no tendremos que preocuparnos m�s por eso, no mientras nosotros estemos vigilantes.~ 


== PLAYER1 IF ~InParty("Uldar")~ THEN ~Una �ltima cosa Hendak, en el barco descubrimos que un nuevo cliente de Haegan hab�a comprado un buen n�mero de ni�os y que estaba pendiente de hacerse con m�s...~
== HENDAK IF ~InParty("Uldar")~ THEN ~�Maldito! �Hab�is descubierto algo sobre ese cerdo o del paradero de los ni�os?~
== PLAYER1 IF ~InParty("Uldar")~ THEN ~Solo sabemos que hay hombres serpiente implicados y que siguen las ordenes de uno al que llaman el Profeta. De este no sabemos nada y tampoco sabemos donde se haN llevado a los ni�os o que pretendeN hacer con ellos pero el asunto tiene ciertos tintes de secta religiosa que no pinta nada bien.~  
== HENDAK IF ~InParty("Uldar")~ THEN ~Con esos datos en poco puedo ayudarte pero investigar� a ver que descubro. Este negocio que le arrebat� a Lehtinan me permite conocer a mucha gente y  tener muchos contactos. Si escucho algo sobre el tema os lo har� saber.~
== HENDAK IF ~InParty("Uldar")~ THEN ~Ahora tengo que dejaros. �Buena suerte amigos!~
== ULDARJ IF ~InParty("Uldar")~ THEN ~Hasta pronto.~
END


I_C_T FIRKRA02 21 UldarFirkraag
== UldarJ IF ~InParty("Uldar")~ THEN ~�En mi pueblo solo existe una vieja leyenda que narre el combate de un Hatuk contra un drag�n rojo...Este sin duda es m�s grande y feroz...�Qu� historias tan magnificas podr�an cantar los bardos de nuestra victoria sobre tan vil criatura!.~
END


I_C_T YOSHJ 113 UldarYoshimo
== UldarJ IF ~InParty("Uldar")~ THEN ~��Ummf, traici�n!! �Los Hatuk la castigamos con la muerte pues no hay cosa peor que la felon�a de un camarada!.~
END


I_C_T PPSAEM2 17 UldarSaemon
== UldarJ IF ~InParty("Uldar")~ THEN ~La Infraoscuridad...Cuentan cosas terribles de ese lugar...Los ancianos nos tienen prohibido adentrarnos en ella pero si es tu deseo <CHARNAME>, yo, Uldar de la Tribu de los Hatuk, te acompa�ar� en tan oscuro viaje.~
END

I_C_T BODHI 11 UldarBodhi1
== UldarJ IF ~InParty("Uldar")~ THEN ~Aceptar� cualquiera que sea tu decisi�n <CHARNAME> pero esto no me da buena espina, mi olfato me dice que hay algo sobrenatural y malvado hay en esta mujer...cuidado.~
END

I_C_T UDSILVER 35 UldarAdalon
== UldarJ IF ~InParty("Uldar")~ THEN ~�JA!  �Yo convertido en un drow!  Si los de mi tribu me vieran ahora, se quedaban todos de piedra. �JA,JA,JA!~
END

I_C_T PLAYER1 18 UldarIrenicusDead
== UldarJ IF ~InParty("Uldar")~ THEN ~�Ancestros, qu�...! ��UUUARRRGGGgggg!!~
END

I_C_T PLAYER1 25 UldarInfierno
== UldarJ IF ~InParty("Uldar")~ THEN ~�D�nde...? �D�nde estamos?... El cielo tiene un extra�o color y esas nubes... qu� extra�o es todo...~
END


I_C_T HELLJON 7 UldarIrenicusInfierno1
== UldarJ IF ~InParty("Uldar")~ THEN ~��MAGO!! �Los Espiritus Sagrados claman venganza por tus fechor�as! �Preparate! �Vas a sentir mi furia!~ 
END

I_C_T HELLJON 8 UldarIrenicusInfierno2
== UldarJ IF ~InParty("Uldar")~ THEN ~��MAGO!! �Los Espiritus Sagrados claman venganza por tus fechor�as! �Preparate! �Vas a sentir mi furia!~ 
END

I_C_T HELLJON 9 UldarIrenicusInfierno3
== UldarJ IF ~InParty("Uldar")~ THEN ~��MAGO!! �Los Espiritus Sagrados claman venganza por tus fechor�as! �Preparate! �Vas a sentir mi furia!~ 
END

I_C_T HELLJON 10 UldarIrenicusInfierno4
== UldarJ IF ~InParty("Uldar")~ THEN ~��MAGO!! �Los Espiritus Sagrados claman venganza por tus fechor�as! �Preparate! �Vas a sentir mi furia!~ 
END


//************************************************************


EXTEND_BOTTOM PLAYER1 33
IF ~IsValidForPartyDialog("Uldar") Global("UldarLealtad","GLOBAL",0)~ THEN DO ~SetGlobal("UldarLealtad","GLOBAL",1)~ GOTO P133Uldar
END

APPEND PLAYER1
  IF ~~ P133Uldar
   SAY ~Uldar, guerrero de la tribu b�rbara de los Hatuk. Su portentosa fuerza y su habilidad en el combate ha sido crucial en m�s de una ocasi�n. Jur� acompa�arte pero quiz�s el paso que vas a dar ahora es m�s de lo que se le pueda pedir a cualquiera. Aunque sabes que su c�digo de honor har� que te siga hasta la muerte sientes que debes darle la opci�n de seguir adelante o quedarse atr�s.~
   ++ ~Uldar, quiz�s no volvamos, �est�s seguro de querer seguir adelante?.~ EXTERN UldarJ doordie
   ++ ~Si me sigues, puede que nunca vuelvas a ver a los de tu tribu. Entender�a que decidieras no continuar.~ EXTERN UldarJ bowout
   ++ ~Uldar, sin ti no podr�a haber llegado hasta aqu� y por ello te estoy muy agradecido. Dime guerrero, �puedo contar contigo en este tramo final de mi viaje?.~ ~Uldar, sin ti no podr�a haber llegado hasta aqu� y por ello te estoy muy agradecida. Dime guerrero, �puedo contar contigo en este tramo final de mi viaje?.~EXTERN UldarJ thankyou
  END
END

APPEND UldarJ

  IF ~~ doordie
   SAY ~�Por los Ancianos!�Qu� pregunta es esa? Uldar no deshonrar� a su tribu y menos a�n abandonar� a su suerte a un camarada. �VAMOS! �Estoy impaciente por entrar en combate!.~ 
  IF ~~ GOTO tolend
  END

  IF ~~ bowout
   SAY ~Mi pueblo, mi gente... S� podr�a ser que sucediera lo que dices pero peor a�n ser�a volver a verlos y no poder mirarlos a la cara sabiendo que he dado la espalda a un amigo y a mi juramento. ��No ser� as�!! �<CHARNAME>, muestra el camino porque Uldar, de la tribu de los Hatuk, permanecer� contigo hasta el final!~
  IF ~~ GOTO tolend
  END

  IF ~~ thankyou
   SAY ~�Por su puesto <CHARNAME>! �Hay un malvado mago que ha de pagar por sus cr�menes y cientos de bardos esperan cantar nuestra gesta! �Adelante camarada, la batalla final nos espera!.~ 
  IF ~~ GOTO tolend
  END

  IF ~~ tolend
   SAY ~�Vamos! �El honor y la gloria nos aguardan!~
   COPY_TRANS PLAYER1 33 
  END

END

//******************************************************
//******************************************************

BEGIN ~BUldar~

IF ~Global("DialogosconUldar","LOCALS",2)~ THEN BEGIN UldarBanner01
  SAY ~�Estoy muy contento de hacer este viaje contigo <CHARNAME>!.~ 
  IF ~~ THEN REPLY ~A mi tambi�n me agrada tenerte en el grupo Uldar. �Eres un gran guerrero!~ GOTO UldarBanner02
  IF ~~ THEN REPLY ~S�. Yo tambi�n estoy muy complacido de que est�s de mi parte. Hasta ahora est�s cumpliendo tu juramento tal y como prometiste~ ~S�. Yo tambi�n estoy muy complacida de que est�s de mi parte. Hasta ahora est�s cumpliendo tu juramento tal y como prometiste~ GOTO UldarBanner02
  IF ~~ THEN REPLY ~Est� bien, pero callate ahora, no es el momento de hablar~ DO ~SetGlobalTimer("UldarDialogo","GLOBAL",FOUR_DAYS) IncrementGlobal("DialogosconUldar","LOCALS",1) ~ EXIT
END

IF ~~ THEN BEGIN UldarBanner02
  SAY ~Me alegra que pienses eso, pues ser un gran guerrero y fiel a mi juramento es la senda que he decidido recorrer... �S�!... me gustar�a que alg�n d�a los Ancianos de mi tribu llegaran a cantar mis gestas y que mi nombre sirviera de inspiraci�n a los jovenes Hatuk; Que sonara con igual fuerza y devoci�n que el de Frandar el Matadragones, Thrungor el Rencoroso o Cerigan el Inmortal... ~
      =
      ~�S�! No cabe duda. Presiento que este viaje a tu lado me va a dar m�s de una ocasi�n de mostrarme como un digno miembro de mi tribu.~   
   IF ~~ THEN REPLY ~Vaya, veo que es muy importante para ti dejar en buen lugar a los de tu tribu...eso sin duda te honra.~ GOTO UldarBanner03a
   IF ~~ THEN REPLY ~Siempre est�s hablando de tu tribu Uldar, aunque no entiendo por qu� les tienes tanta lealtad a ellos y a sus normas.~ GOTO UldarBanner03a
   IF ~~ THEN REPLY ~�Frandar el Matadragones? �Thrungor el Rencoroso? �Cerigan el Inmortal?...Esos nombres no me suenan pero me gustar�a conocer sus gestas. En Candelero pude leer muchas historias y leyendas de heroes pasados pero uno siempre tiene ganas de m�s.~ ~�Frandar el Matadragones? �Thrungor el Rencoroso? �Cerigan el Inmortal?...Esos nombres no me suenan pero me gustar�a conocer sus gestas. En Candelero pude leer muchas historias y leyendas de heroes pasados pero una siempre tiene ganas de m�s.~GOTO UldarBanner03b
END


IF ~~ THEN BEGIN UldarBanner03a
  SAY ~No podr�a ser de otra forma <CHARNAME>...Has de saber que fueron ellos, una tribu de humanos n�madas de los Picos Nublados, los que me rescataron de los brazos de la muerte...~
      =
      ~Los Ancianos me han contado muchas veces como un grupo de caza de mi tribu me encontr� entre los restos humeantes de una aldea minera que hab�a sido arrasada por orcos. Los Hatuk me acogieron y me criaron como a uno m�s de la tribu...~
      =
      ~Uldar me llamaron, nombre que significa "Colmillo Encontrado". Has de saber que mi gente venera al Lobo Sagrado de las Tres Colas, cada miembro de mi tribu es uno de los incontables dientes de sus grandes fauces, un Hatuk.... Como ves, no puedo m�s que sentir agradecimiento y orgullo hacia los mios y es por esa raz�n que, con el consentimiento de los Ancianos, decid� viajar por un tiempo a lo largo de la Costa de la Espada... Con esto quiero agradecerles todo lo que han hecho por mi, quiero que, con mis actos y mis gestas, se sientan orgullosos y reconocidos por las dem�s tribus...~
  IF ~~ THEN REPLY ~Comprendo. Es muy elogiable lo que quieres hacer. La tribu de los Hatuk tiene mucha suerte de poder contar contigo.~ DO ~SetGlobalTimer("UldarDialogo","GLOBAL",FOUR_DAYS) IncrementGlobal("DialogosconUldar","LOCALS",1) ~ EXIT
  IF ~~ THEN REPLY ~Entiendo. Por lo que a mi respecta puedes seguir con tu idea de ganar fama y gloria...siempre y cuando cumplas con tu juramento..~ DO ~SetGlobalTimer("UldarDialogo","GLOBAL",FOUR_DAYS) IncrementGlobal("DialogosconUldar","LOCALS",1) ~ EXIT
END


IF ~~ THEN BEGIN UldarBanner03b
  SAY ~Bien <CHARNAME>, no s� donde queda ese Candelero del que hablas ni que historias habr�s conocido pero si se da la ocasi�n te contar� alguna que otra gesta de los grandes heroes de los Hatuk y ver�s como hay pocos que puedan superarlos en valor y fuerza.~
  IF ~~ THEN REPLY ~�Estupendo! �Me encantar� escucharlas!~ DO ~SetGlobalTimer("UldarDialogo","GLOBAL",FIVE_DAYS) IncrementGlobal("DialogosconUldar","LOCALS",1) ~ EXIT
END

IF ~Global("DialogosconUldar","LOCALS",4)~ THEN BEGIN UldarBanner04
  SAY ~<CHARNAME>, �te he contado alguna vez la historia Thrungor el Rencoroso?~ 
  IF ~~ THEN REPLY ~No Uldar, aunque me gustar�a me la contases.~ GOTO UldarBanner05
  IF ~~ THEN REPLY ~Lo siento Uldar pero no es un buen momento. Tal vez en otra ocasi�n.~ DO ~IncrementGlobal("DialogosconUldar","LOCALS",1)~ EXIT
END

IF ~~ THEN BEGIN UldarBanner05
  SAY ~Ver�s, Thrungor fue el segundo hijo de Plassar, el XXI Portador de la Corona de Colmillos de nuestro pueblo. Cuentan los ancianos que su padre y su hermano mayor cayeron en una emboscada orca mientras cazaban venados poco antes de la llegada de las primeras nieves. Cuentan que los orcos los decapitaron y que los Hatuk solo pudieron dar entierro a los cuerpos sin cabeza. Esto enfureci� muchisimo a todos los Hatuk y m�s si cabe a Trungor que, desoyendo el consejo de los Ancianos y no esperando a que se eligiera a un nuevo Portador de la Corona de Colmillos que dirigiera a todos los guerreros, se adentro en territorio orco armado con el hacha de su hermano mayor en una mano y la espada rota de su padre en la otra.~
      =
      ~Se cuenta que dos d�as m�s tarde, una vez elegido a un nuevo Portador de la Corona de Colmillos, los guerreros Hatuk entraron tambi�n en territorio orco hasta llegar, sin ning�n tipo de oposici�n, a la misma aldea orca. All� descubrieron porqu� no les sali� al paso ning�n orco: En medio de la aldea orca, formada por un monton de chozas de mohosa madera y pieles  malorientes, se alzaba una gran monta�a de orcos muertos y sobre �sta yacia inerte, a causa de las heridas recibidas, Thrungor, el segundo hijo de Plassar el Decapitado. Se lo encontrar�n desangrado, con los calzones bajados y una gran sonrisa. El gran guerrero, utiliz� sus �ltimas fuerzas para apilar a todos los cadaveres de los orcos que hab�a matado, subirse encima de la monta�a de cadaveres y cagarse encima de ellos.~
      =
      ~�JA,JA,JA,JA! �Me encanta esta historia! Desde entonces son pocos los orcos que se hayan atrevido a levantar su brazo contra los nuestros... De esto ya ha pasado mucho tiempo pero a los orcos todav�a les HUELE como el primer d�a. �JA, JA, JA,JA!~
  IF ~~ THEN REPLY ~�Ja,ja,ja! S� que es buena esta historia de Thrungor el Rencoroso. �Ja,ja,ja! ~ GOTO UldarBanner06
  IF ~~ THEN REPLY ~�Prefirio cagarse encima de los orcos en vez de curarse primero las heridas?...Sin duda el apodo del Rencoroso se lo gan� a pulso...~ GOTO UldarBanner06
END

IF ~~ THEN BEGIN UldarBanner06
  SAY ~S�, el apodo lo tiene ganado a pulso...Esta es sin duda una buena historia Hatuk que trae con ella dos grandes ense�anzas: la primera es que la determinaci�n y la furia de un guerrero Hatuk es siempre imparable y la segunda que desoir el consejo de los Ancianos puede traerte graves consecuencias.~
IF ~~ THEN DO ~IncrementGlobal("DialogosconUldar","LOCALS",1)~ EXIT
END

//**********************


CHAIN
IF ~InParty("Minsc") InParty("Uldar") See("Minsc ") !StateCheck("Minsc",STATE_SLEEPING) Global("BUldarMinsc","LOCALS",0)~ THEN BMINSC TCHAIN101
~�Uldar, eres un gran guerrero! Estoy seguro de que entre los Hatuk tienes una gran reputaci�n.~ DO ~SetGlobal("BUldarMinsc","LOCALS",1)~
== BUldar ~Agradezco tus palabras, pero entre los Hatuk no era sino otro de los tantos colmillos que tiene las fauces del Lobo Sagrado de las Tres Colas, solo eso...Pero no te negar� que alg�n d�a me gustar�a ser el portador de la Corona de Colmillos y ser reconocido entre los de mi tribu como uno de sus grandes heroes.~
== BMINSC ~S�, lo entiendo. Minsc tambi�n empez� hace tiempo su dajemma para que a su vuelta los suyos le reconociesen como un guerrero apto y valeroso... Pero no me est� resultando f�cil, muchas veces he recibido buenos porrazos... aunque lo pero fue perder a mi buena amiga Dynaheir, la bruja con la que part� de Rashemen y a la que jur� proteger...~
== BUldar ~Mi p�same por tu perdida... pero no has de venirte abajo, todo lo contrario, has de sobreponerte  y reemprender tu misi�n con m�s entusiasmo y entrega que antes, solo as� honrar�s a tu amiga y a tu gente.~
== BMINSC ~...Hablas sabiamente compa�ero...me recuerdas a mi maestro y a sus ense�anzas, cuando me adiestraban de joven~
== BUldar ~No es extra�o eso que dices pues esa sabidur�a no es m�a, es lo que me dec�an a mi los Ancianos cuando fracasaba en alguna de las tareas.~
== BMINSC ~ Veo que hay mucho en com�n entre nuestros pueblos. �Me alegra poder luchar a tu lado Uldar!...�Ooh s�, y Bub� tambi�n se alegra un mont�n! �Verdad Bub�?~
EXIT



CHAIN
IF ~InParty("Viconia") InParty("Uldar") See("Viconia") !StateCheck("Viconia",STATE_SLEEPING) Global("BUldarViconia","LOCALS",0)~ THEN BUldar TCHAIN102
~Tus artes son sorprendentes Viconia...viendote en acci�n he comprendido que mis Ancianos no exageraban cuando nos relataban alguna historia que tuviera que ver con vosotros.~ DO ~SetGlobal("BUldarViconia","LOCALS",1)~
==BVICONI ~Haces bien en sorprenderte, aunque har�as mejor en temernos guerrero. No en vano somos los amos y se�ores de la Infraoscuridad.~
==BUldar ~�Temeros? �Un Hatuk no tiene miedo a nada!~
==BVICONI ~�No seas tan ligero en esa aseveraci�n!. La senda que marca Shar es muy oscura pero a veces deja ver en los sue�os m�s all� de lo que hace nuestra vista... Es muy probable que alg�n d�a tengas que luchar contra los de mi raza...entonces veremos cuan valiente eres.~ 
EXIT




















