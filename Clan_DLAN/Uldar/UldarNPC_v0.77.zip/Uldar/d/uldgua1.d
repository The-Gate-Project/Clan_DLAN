BEGIN ~ULDGUA1~

IF ~NumTimesTalkedTo(0) !Dead("announcer") !StateCheck("announcer",STATE_SLEEPING)~ THEN BEGIN 0
  SAY ~�Suelta el arma semiorco! �Has luchado bien, pero ya es hora de que vuelvas a tu celda!~
  IF ~~ THEN EXTERN ~Uldarsc1~ 1
END

IF ~~ THEN BEGIN 1
  SAY ~�Calma gladiador! Recuerda a los ni�os. Cualquier muestra de rebeli�n hacia tus amos les costar� la vida a esos crios.~
=
~ �Y ahora muevete! Te llevamos de nuevo a tu celda. Hay de dejar libre el pozo para el siguiente combate.~
IF ~~ THEN EXIT
END