
BEGIN ~GIRL1~

IF ~NumTimesTalkedTo(0)
~ THEN BEGIN 0 
  SAY ~�Hey! �Qui�n eres t�? No has venido a hacerme da�o, �verdad?~ 
  IF ~~ THEN REPLY ~No, peque�a. Estoy aqu� para liberarte. R�pido.~ GOTO 1
  IF ~~ THEN REPLY ~No seas tonta, chica. Eres libre, �mu�vete!~  GOTO 1
END

IF ~~ THEN BEGIN 1 
  SAY ~�Oh...oh! <�sollozo!> �Soy libre? �Oh, gracias, se�or, gracias!~ ~�Oh...oh! <�sollozo!> �Soy libre? �Oh, gracias, se�ora, gracias!~ 
  IF ~~ THEN DO ~SetGlobal("Celdani�oUldar","GLOBAL",1) AddexperienceParty(2500) EscapeArea() ~ EXIT
END
