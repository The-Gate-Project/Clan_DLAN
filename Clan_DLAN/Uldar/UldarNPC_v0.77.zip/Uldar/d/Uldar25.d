BEGIN ~Uldar25~


IF ~Global("UldarSummoned","GLOBAL",1)~ THEN BEGIN InvocarUldar1 
  SAY ~��<CHARNAME>?!...�El espiritu del Lobo Sagrado de las Tres Colas me advirti� de tu llamada y alguna especie de brujer�a me ha traido hasta aqu�!...�Qu� sucede?~
IF ~~ THEN REPLY ~Te necesito nuevamente Uldar, quiero que hagas honor a tu promesa y te unas a mi. Por lo que s�, la saga de los Hijos de Bhaal est� llegando a su fin y voy a necesitar de tu fuerza y tu destreza en el combate para salir victorioso.~ DO ~SetGlobal("UldarSummoned","GLOBAL",2)~ GOTO EnEquipo
IF ~~ THEN REPLY ~Te he llamado porque me vendr�a muy bien contar contigo Uldar. �Me har�s el honor de luchar nuevamente a mi lado?~ DO ~SetGlobal("UldarSummoned","GLOBAL",2)~ GOTO EnEquipo
END


IF ~~ THEN BEGIN EnEquipo 
  SAY ~No tienes que seguir hablando <CHARNAME>. El juramento de un guerrero Hatuk es sagrado y as� se ver� cumplido. Solo tienes que mandar que yo obedecer�... la caza del venado en los Picos Nublados puede esperar.~
  IF ~~ THEN REPLY ~�Estupendo! Vamos entonces, hay mucho que hacer.~ DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY ~�Excelente! Me alegra saber que puedo contar contigo. Espera aqu�, pronto volver� a por ti~ GOTO Fuera
END



IF ~~ THEN BEGIN Fuera 
  SAY ~Como desees...pero no tardes mucho, este lugar no es natural...no me gusta, me siento como un lobo en medio del mar...~ 
  IF ~~ THEN DO ~SetGlobal("UldarFuera","GLOBAL",1) MoveToPointNoInterrupt([2550.1436]) Face(0)~ EXIT
END


IF ~Global("UldarFuera","GLOBAL",1)~ THEN DentroBis                //Nunca ha estado dentro
  SAY ~�Nos vamos ya?. Estoy deseando salir de aqu� y volver a respirar aire fresco~ 
  IF ~~ THEN REPLY ~S�, vamos.~ DO ~JoinParty() SetGlobal("UldarFuera","GLOBAL",0)~ EXIT
  IF ~~ THEN REPLY ~Espera un poco m�s. Pronto partiremos.~ EXIT
END


//******************************************************************
//******************************************************************

BEGIN ~Uldar25p~

IF ~Global("UldarKickedOut","GLOBAL",0)~ THEN BEGIN AbandonarGrupo
  SAY ~�Es lo que quieres?.~
  IF ~~ THEN REPLY ~�No! Perdona, no se en que estaba pensando.~ DO ~SetGlobal("UldarKickedOut","GLOBAL",0) JoinParty()~ EXIT
  IF ~AreaCheck("AR4500")~ THEN REPLY ~S�, es lo mejor por el momento.~ DO ~SetGlobal("UldarKickedOut","GLOBAL",1) MoveToPointNoInterrupt([2550.1436]) Face(0)~ EXIT
  IF ~!AreaCheck("AR4500") !AreaCheck("AR4000") !AreaCheck("AR6200")~ THEN REPLY ~S�, es lo m�s conveniente. Pero te voy a enviar de vuelta a la Bolsa Planar porque es probable que pronto te vuelva a necesitar. Esperame all�.~ DO ~SetGlobal("UldarKickedOut","GLOBAL",1)  CreateVisualEffectObject("SPDIMNDR",Myself) Wait(2) MoveBetweenAreas("AR4500",[2550.1436],0)~ EXIT
  IF ~!AreaCheck("AR4500") !AreaCheck("AR4000") !AreaCheck("AR6200")~ THEN REPLY ~Es necesario Uldar. Espera aqu�, pronto volver�.~ DO ~SetGlobal("UldarKickedOut","GLOBAL",1)~ EXIT
END



IF ~Global("UldarKickedOut","GLOBAL",1)~ THEN BEGIN RegresarGrupo 
  SAY ~�Ya era hora!. Empezaba a pensar que me ibas a dejar aqu� para los restos~
  IF ~~ THEN REPLY ~Nada de eso Uldar. �Vamos!~ DO ~SetGlobal("UldarKickedOut","GLOBAL",0) JoinParty()~ EXIT
  IF ~~ THEN REPLY ~Se que es duro para ti per necestio que esperes un poco m�s. Pronto volver�.~ GOTO Paciencia
  IF ~~ THEN REPLY ~Tranquilo guerrero. Se paciente, en breve volveremos a viajar juntos.~ GOTO Paciencia
END


IF ~~ THEN BEGIN Paciencia 
  SAY ~Umff...vale, pero no tardes mucho.~ 
  IF ~~ THEN EXIT
END


//****************************************************************
//****************************************************************

BEGIN ~Uldar25j~


I_C_T BAZDRA01 0 UldarAvisoDraconis
== Uldar25J IF ~InParty("Uldar")~ THEN ~*Sniff*, *sniff*...Aqu� huele a sierpe pero no la veo...que extra�o.~
END


I_C_T SOLAR 67 UldarDecision
== Uldar25J IF ~InParty("Uldar")~ THEN ~�Por fin. Tenemos a Melisan a tiro de piedra compa�ero! �S�!... �Esta ser� sin duda una batalla que cantaran los bardos hasta el fin de los tiempos! ��ADELANTE!!~
END

I_C_T FINSOL01 27 UldarAscendChoice
== Uldar25J IF ~InParty("Uldar")~ THEN ~El poder de un dios est� a tu alcance...dan escalofrios solo de pensarlo. <CHARNAME>, no soy quien para dar consejos sobre esto...creo que ni los Ancianos de mi tribu ser�an capaces de hacerlo...pero decidas lo que decidas estar� contigo.~
END



//********************************************************************


EXTEND_TOP SARVOLO 9 #7
IF ~InParty("Uldar")~ THEN REPLY ~Hablame de Uldar.~ GOTO VoloUldar
END

CHAIN SARVOLO VoloUldar
~Uldar, el orgulloso b�rbaro de la tribu de los Hatuk. Su valor y furia en combate son m�s que conocidas y sus gestas empiezan a cantarse por toda la Costa de la Espada... Uldar, "Colmillo Encontrado", el m�s audaz entre los suyos va camino de convertise en una leyenda viva, orgullo para su tribu e inspiraci�n para los nuevos guerreros.~ 

== Uldar25J IF ~IsValidForPartyDialog("Uldar")~ THEN ~Vaya, no est� nada mal... No cre�a que tuviera ya tanta fama...Me pregunto si realmente mi gente siente eso por mi...~
EXTERN SARVOLO 9


//*******************************************************************
//*******************************************************************

BEGIN ~BUldar25~

CHAIN
IF ~InParty("Sarevok") See("Sarevok") !StateCheck("Sarevok",STATE_SLEEPING) Global("BUldarSarevok","LOCALS",0)~ THEN BUldar25 TCHAIN110
~Sarevok, eres sin duda un gran guerrero. He visto muy pocas veces una destreza tal en el combate...~ DO ~SetGlobal("BUldarSarevok","LOCALS",1)~
== BSAREV25 ~�Dejame en paz semiorco!~
EXIT




