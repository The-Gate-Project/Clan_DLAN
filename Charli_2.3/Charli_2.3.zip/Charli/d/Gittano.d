BEGIN ~Gittano~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN PrimeraVenta
  SAY @0  
  IF ~~ THEN REPLY @1 GOTO Regatear
END

IF ~~ THEN BEGIN Regatear
  SAY @2 
  IF ~~ THEN REPLY @3 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @4 GOTO Dudas
END

IF ~~ THEN BEGIN Dudas
  SAY @5
  IF ~~ THEN REPLY @6 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @7 GOTO Huir
  IF ~~ THEN REPLY @8 EXIT
END

IF ~~ THEN BEGIN Huir
  SAY @9 
  IF ~~ THEN DO ~SetGlobal("GittaHuye","GLOBAL",1)~ EXIT
END

IF ~!NumTimesTalkedTo(0) !InParty("Jan") GlobalLT("Chapter","GLOBAL",6)~ THEN BEGIN Regreso
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END


//***********************************************************************


IF ~!NumTimesTalkedTo(0) InParty("Jan") Global("CharliJan","LOCALS",0) Global("DineroparaCharli","LOCALS",0)~ THEN BEGIN SaludosCharli1
  SAY @13
  IF ~~ THEN REPLY @14 GOTO OfertaCharli1
END

IF ~~ THEN BEGIN OfertaCharli1
  SAY @15
  IF ~~ THEN REPLY @16 DO ~SetGlobal("DineroparaCharli","LOCALS",1)~ EXIT
  IF ~PartyGoldGT(4999)~ THEN REPLY @17 DO ~TakePartyGold(5000) SetGlobal("CharliJan","LOCALS",1) SetGlobal("DineroparaCharli","LOCALS",2) TakePartyItem("xbow12") DestroyItem("xbow12") CreateItem("Xbowx2jj",1,1,0) GiveItem("Xbowx2jj",LastTalkedToBy)~ EXIT
END

IF ~Global("CharliJan","LOCALS",0) Global("DineroparaCharli","LOCALS",1)~  THEN BEGIN DineroCharli1
  SAY @18   
  IF ~PartyGoldGT(4999)~ THEN REPLY @17 DO ~TakePartyGold(5000) SetGlobal("CharliJan","LOCALS",1) SetGlobal("DineroparaCharli","LOCALS",2) TakePartyItem("xbow12") DestroyItem("xbow12") CreateItem("Xbowx2jj",1,1,0) GiveItem("Xbowx2jj",LastTalkedToBy)~ EXIT
  IF ~~ THEN REPLY @19 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT 
END


//************************************************************************


IF ~InParty("Jan") Global("CharliJan","LOCALS",1) Global("DineroparaCharli","LOCALS",2)~ THEN BEGIN SaludosCharli2
  SAY @20
  IF ~~ THEN REPLY @21 GOTO OfertaCharli2
END

IF ~~ THEN BEGIN OfertaCharli2
  SAY @22
  IF ~~ THEN REPLY @23 GOTO HistoriaJanCharli
  IF ~PartyGoldGT(9999)~ THEN REPLY @24 DO ~TakePartyGold(10000) SetGlobal("CharliJan","LOCALS",2) TakePartyItem("xbowx2jj") DestroyItem("xbowx2jj") CreateItem("Xbowx3jj",1,1,0) GiveItem("Xbowx3jj",LastTalkedToBy)~ EXIT
END


IF ~~ THEN BEGIN HistoriaJanCharli
  SAY @25
  IF ~~ THEN REPLY @26 DO ~SetGlobal("DineroparaCharli","LOCALS",3)~ EXIT
END


IF ~Global("DineroparaCharli","LOCALS",3)~  THEN BEGIN DineroCharli2
  SAY @18   
  IF ~PartyGoldGT(9999)~ THEN REPLY @27 DO ~TakePartyGold(10000) SetGlobal("CharliJan","LOCALS",2) SetGlobal("DineroparaCharli","LOCALS",4) TakePartyItem("xbowx2jj") DestroyItem("xbowx2jj") CreateItem("Xbowx3jj",1,1,0) GiveItem("Xbowx3jj",LastTalkedToBy)~ EXIT
  IF ~~ THEN REPLY @19 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT 
END

//**************************************************************************

IF ~!NumTimesTalkedTo(0) Global("CharliJan","LOCALS",2) GlobalLT("Chapter","GLOBAL",6) ~ THEN BEGIN Regreso1
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END





//**************************************************************************
//**************************************************************************
//**************************************************************************




IF ~!NumTimesTalkedTo(0) Global("CharliJan","LOCALS",2) GlobalGT("Chapter","GLOBAL",5) !PartyHasItem("karayo") Global("FabRaiden","GLOBAL",0)~ THEN BEGIN Regreso2
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END


IF ~!NumTimesTalkedTo(0) !InParty("Jan") GlobalGT("Chapter","GLOBAL",5) !PartyHasItem("karayo") Global("FabRaiden","GLOBAL",0)~ THEN BEGIN Regreso3
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END




//**************************************************************************
//**************************************************************************




IF ~!NumTimesTalkedTo(0) GlobalGT("Chapter","GLOBAL",5) PartyHasItem("karayo") Global("FabRaiden","GLOBAL",0)~ THEN BEGIN Ofertakaraiden
  SAY @28 
  IF ~~ THEN REPLY @29 GOTO FabricarRaiden  
END


IF ~~ THEN BEGIN FabricarRaiden
  SAY @30
  IF ~~ THEN REPLY @31 GOTO PastaRaiden
END


IF ~~ THEN BEGIN PastaRaiden
  SAY @32
      =
      @33
      =
      @34
  IF ~PartyGoldLT(15000)~ THEN REPLY @35 DO ~SetGlobal("FabRaiden","GLOBAL",1)~ EXIT
  IF ~OR(3) !NumItemsPartyGT("misc42",4) !NumItemsPartyGT("helm18",0) !NumItemsPartyGT("helm19",1)~ THEN REPLY @36 DO ~SetGlobal("FabRaiden","GLOBAL",1)~ EXIT
  IF ~PartyGoldGT(14999) NumItemsPartyGT("misc42",4) NumItemsPartyGT("helm18",0) NumItemsPartyGT("helm19",1)~ THEN REPLY @37 GOTO TratoRaiden
  IF ~~ THEN REPLY @38 DO ~SetGlobal("FabRaiden","GLOBAL",1)~ EXIT
  IF ~~ THEN REPLY @39 DO ~SetGlobal("FabRaiden","GLOBAL",1) StartStore("BAGitta", LastTalkedToBy())~ EXIT
END




//**************************************************************************




IF ~!NumTimesTalkedTo(0) Global("FabRaiden","GLOBAL",1)~ THEN BEGIN InsisteRaiden1
  SAY @10 
  IF ~PartyGoldGT(14999) NumItemsPartyGT("misc42",4) NumItemsPartyGT("helm18",0) NumItemsPartyGT("helm19",1)~ THEN REPLY @40 GOTO TratoRaiden
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END



//**************************************************************************





IF ~~ THEN BEGIN TratoRaiden
  SAY @41
  IF ~~ THEN REPLY @42 DO ~SetGlobal("FabRaiden","GLOBAL",2) SetGlobalTimer("RaidenTerminada","GLOBAL",FIVE_DAYS) TakePartyItem("Karayo") DestroyItem("Karayo") TakePartyItem("misc42") DestroyItem("misc42")  TakePartyItem("misc42") DestroyItem("misc42") TakePartyItem("misc42") DestroyItem("misc42") TakePartyItem("misc42") DestroyItem("misc42") TakePartyItem("misc42") DestroyItem("misc42") TakePartyItem("helm18") DestroyItem("helm18") TakePartyItem("helm19") DestroyItem("helm19") TakePartyItem("helm19") DestroyItem("helm19") TakePartyGold(15000)~ EXIT
END




//**************************************************************************

IF ~!NumTimesTalkedTo(0) Global("FabRaiden","GLOBAL",2)~ THEN BEGIN VentaesperandoRaiden
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END


//**************************************************************************




IF ~!NumTimesTalkedTo(0) Global("FabRaiden","GLOBAL",3)~ THEN BEGIN EntregaRaiden        
  SAY @43 
  IF ~~THEN REPLY @44 DO ~SetGlobal("FabRaiden","GLOBAL",4) CreateItem("KaRaiden",1,1,0) GiveItem("KaRaiden",LastTalkedToBy)~ EXIT
END



//**************************************************************************

IF ~!NumTimesTalkedTo(0) Global("FabRaiden","GLOBAL",4)~ THEN BEGIN VentaNormal1
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~StartStore("BAGitta", LastTalkedToBy())~ EXIT
  IF ~~ THEN REPLY @12 EXIT
END



