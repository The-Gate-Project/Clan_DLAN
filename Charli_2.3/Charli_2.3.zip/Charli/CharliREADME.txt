JUEGO:      Baldur's Gate II
MOD: 	    CHARLI, El mediano vendedor de los Barrios Bajos
VERSI�N:    2.3
CREADOR:    Sergiond

Por favor contacta con Sergiond ( sergiond77@hotmail.com ) si encuentras en el mod alg�n error u otro imprevisto.


�NDICE:
  	 I. Instalaci�n y desinstalaci�n
        II. Compatibilidades
       III. Acerca del mod
        IV. Cr�ditos
        VI. Versiones

I. INSTALACI�N:

- Asegurate previamente de que has instalado correctamente BG2: SoA y su expansi�n ToB. 
- Aunque no es obligatorio, te aconsejo que te instales el �ltimo parche de ToB.
- Ejecuta el archivo comprimido CharliVendedor.exe y selecciona el directorio principal de BG2.
- Ejecuta Setup-Charli.exe
- Este mod puede ser instalado/desinstalado sin causar ning�n problema a la instalaci�n de BG2.
- Para DESINSTALAR:  Ejecuta de nuevo Setup-Charli.exe y te dar� las opciones de reinstalar o desinstalar.

II. COMPATIBILIDADES:

- Este mod es compatible con SoA y con ToB. Por otro lado es obligatorio tener ambas instaladas.
- Es compatible tambi�n con cualquier otro mod ya que est� compilado con Weidu.

III. ACERCA DEL MOD:

  En el mod Charli podr�s encontrar a un mediano vendedor de bolsas y otros objetos de dudosa procedencia. 
  Est� situado en los Barrios Bajos de Athkatla, cerca de la entrada a la Corona de Cobre. 
  

IV. CR�DITOS:

-   Idea y dise�o:                             Sergiond 
-   Programaci�n y desarrollo:                 Sergiond
-   Voces de Charli:                           Sergiond


VI. VERSIONES

  1.0  - Paquete completo de "Charli, el mediano vendedor".
 
  1.1  - Nuevos objetos a la venta: Libro de Agilidad, Yelmo de Throndir     
  
  1.2  - Charli le vende componentes nuevos a Jan Jansen para hacer m�s potente el Lanzadestellantes en 2 ocasiones  

  2.0  - Nuevos objetos a la venta: Rodela Lunar, Hoja del Rayo del Infortunio y Tomo del Pensamiento Claro
       - Un primo del Charli puede mejorar la Hoja del Rayo del Infortunio (despu�s de Infraoscuridad).
       - Bug en un di�logo de venta de componentes para Lanzadestellantes solucionado.
       - Nueva ubicaci�n de la tienda (como cada vez tiene m�s cosas para vender, ahora se trae el carro).
         Cerca de la salida NORTE de los Barrios Bajos 

  2.1  - Arreglos y actualizaci�n de WeiDU por Lollorian.

  2.2  - Commented out the line "EXTEND_TOP ~ar0400.bcs~ ~Charli\baf\A�adir_Gittano.baf~",
         because of missing A�adir_Gittano.baf
       - Corrected and completed version-history
       - Added VERSION-flag

  2.3  - Updated Spanish translation by Lisandro
       - Updated to WeiDU v215
