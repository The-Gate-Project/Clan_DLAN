GAME: 		Baldur's Gate II
MOD: 		Charlie, the middle of the slums seller
VERSION: 	2.3
CREATOR: 	Sergiond

Please contact Sergiond (sergiond77@hotmail.com) if you find any error on the mod or other strange things.


CONTENTS:
   I. Installing and uninstalling
         II. Compatibilities
        III. About the mod
         IV. Credits
         VI. Versions

I. INSTALLATION:

- Make sure that you've previously successfully installed BG2: SoA and ToB expansion.
- Although not required, I recommend that you install the latest patch for ToB.
- Run the archive CharliVendedor.exe and select the main directory of BG2.
- Run Setup-Charli.exe
- This mod can be installed/uninstalled without causing any problem to the installation of BG2.
- To UNINSTALL: Run Setup-Charli.exe again and give you options to reinstall or uninstall.

II. COMPATIBILITY:

- This mod is compatible with SoA and ToB. On the other hand is required to have both installed.
- It also supports any other mod as it is compiled with weidu.

III. ABOUT THE MOD:

   In Charli mod you find a vendor medium bags and other items of questionable origin.
   It is located in the slums of Athkatla, near the entrance to the Corona de Cobre.
  

IV. CREDITS:

- Idea and design: Sergiond
- Programming and Development: Sergiond
- Charli Voices: Sergiond


VI. VERSIONS

  1.0  - Complete package of "Charlie, the median seller.
 
  1.1  - New Items on sale: Book of Agility, Helm Throndir
  
  1.2  - Charli sells new components to Jan Jansen for making the most powerful Flasher Launchers on 2 occasions

  2.0  - New Items for sale: Lunar buckler and Lightning Blade of Misfortune
       - One of Charli's cousins can improve the Lightning Blade of Misfortune (after Underdark).
       - Bug in a sales dialogue component related to Flasher Launchers solved.
       - New location of the store (like everytime you have more things to sell, now brings the car).
         Near the north exit of the slums (Position: 1516,431)

  2.1  - Fixes and updated WeiDU (by Lollorian)

  2.2  - Commented out the line "EXTEND_TOP ~ar0400.bcs~ ~Charli\baf\A�adir_Gittano.baf~",
         because of missing A�adir_Gittano.baf
       - Corrected and completed version-history
       - Added VERSION-flag

  2.3  - Updated Spanish translation by Lisandro
       - Updated to WeiDU v215
